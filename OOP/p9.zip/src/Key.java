public class Key {
    private final int KeyCode;
    private final int first;
    private final int second;
    private final int third;
    
    public Key(){
        int first = ((int)(Math.random() * ((9) + 1)));
        int second = ((int)(Math.random() * ((9) + 1)));
        int third = ((int)(Math.random() * ((9) + 1)));
        boolean keepGoing = true;
        while(keepGoing){
            if(first == second ){
                first = ((int)(Math.random() * ((9) + 1)));
            }
            if(second == third){
                second = ((int)(Math.random() * ((9) + 1)));
            }
            if(first == third){
                third = ((int)(Math.random() * ((9) + 1)));
            }
            keepGoing = (first == second || second == third || third == first);
        }
        this.first = first;
        this.second = second;
        this.third = third;
        first *= 100;
        second *= 10;
        this.KeyCode = first + second + third;
    }

    public int getKey() {
        return KeyCode;
    }   
    
    public String CheckKey(int check){
        if (check == this.KeyCode)
            return "Correct!";
        int Cfirst = check / 100 % 10;
        int Csecond = check / 10 % 10;
        int Cthird = check % 10;
        int strikes = 0;
        int  balls = 0;
        if(this.first == Cfirst)
            strikes++;
        else if(this.first == Csecond || this.first == Cthird)
            balls++;
        if(this.second == Csecond)
            strikes++;
        else if(this.second == Cfirst || this.second == Cthird)
            balls++;
        if(this.third == Cthird)
            strikes++;
        else if(this.third == Csecond || this.third == Cfirst)
            balls++;
        return (strikes + " strikes and " + balls + " balls");
    }
}
