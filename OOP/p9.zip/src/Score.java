public class Score {
    private final String gameType;
    private final int Score;
    
    public Score(String gameType, int Score){
        this.gameType = gameType;
        this.Score = Score;   
    }
    
    public String getScore(){
        return gameType + ": " + Score;
    }
    
    public int getScoreNum(){
        return Score;
    }
    
    public int getType(){
        switch (gameType) {
            case "Hangman":
                return 1;
            case "Baseball":
                return 2;
            default:
                return 3;
        }
    }
}
