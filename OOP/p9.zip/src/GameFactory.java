public interface GameFactory {
    Game createGame();
}