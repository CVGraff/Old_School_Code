public class MyGameFactory implements GameFactory{
    
    private String type;
    
    public MyGameFactory(String type){
        this.type = type;
    }
    
    @Override
    public Game createGame(){
        switch (type) {
            case "Hangman":
                return new HangmanGame();
            case "Baseball":
                return new BaseballGame();
            case "TicTacToe":
                return new TicTacToeGame();
            default:
                return new HangmanGame();
        }
    }
}
