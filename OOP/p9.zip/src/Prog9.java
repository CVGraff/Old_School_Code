
import java.util.Scanner;

public class Prog9 {
    
    public static void main(String[] args){
        boolean gameOn = true;
        GameFactory theGame;
        ScoreCard Card = new ScoreCard();
        while (gameOn) {
            System.out.println("Welcome to Chris Graff's Arcade");
            System.out.println("------------ Main menu ------------");
            System.out.println("1: Hangman");
            System.out.println("2: Baseball");
            System.out.println("3: Tic-Tac-Toe");
            System.out.println("4: Scores");
            System.out.println("5: Exit");
            System.out.println("-----------------------------------");
            System.out.println("What would you like to do? ");

            Scanner scanNumber = new Scanner(System.in);
            String gameChoice = scanNumber.nextLine();

            // User's choice
            switch(gameChoice) {
                case "1":
                    System.out.println("Hangman selected!\n");
                    theGame = new MyGameFactory("Hangman");
                    Card.addScore("Hangman", theGame.createGame().playGame());
                    break;
                case "2":
                    System.out.println("Baseball selected!\n");
                    theGame = new MyGameFactory("Baseball");
                    Card.addScore("Baseball", theGame.createGame().playGame());
                    break;
                case "3":
                    System.out.println("Tic-Tac-Toe selected!\n");
                    theGame = new MyGameFactory("TicTacToe");
                    Card.addScore("TicTacToe", theGame.createGame().playGame());
                    break;
                case "4":
                    System.out.println("Scores selected!\n");
                    System.out.println(Card.printCard());
                    break;
                case "5":
                    gameOn = false;
                    break;
                default:
                    System.out.println("Invalid Input!\n");
                    break;
            }
        }
    }
}
