public class TicTacToe {
    private String boardPosition[][];
    private String Board;
    
    public TicTacToe(){
        this.boardPosition = new String[3][3];
        for(int x=0; x<3; x++){
            for(int y=0; y<3; y++){
                this.boardPosition[x][y] = " ";
            }
        }
        boardUpdate();
    }
    
    public String getBoard(){
        return Board;
    }
    
    public boolean checkMove(int x, int y){
        return boardPosition[y][x].equals(" ");
    }
    
    public void addMove(int x, int y, String XorO){
        this.boardPosition[y][x] = XorO;
        boardUpdate();
    }
    
    private void boardUpdate(){
        this.Board = "+---+---+---+\n";
        this.Board+= "| " + this.boardPosition[0][0] + " | " + this.boardPosition[1][0] + " | " + this.boardPosition[2][0]+ " |\n";
        this.Board+= "+---+---+---+\n";
        this.Board+= "| " + this.boardPosition[0][1] + " | " + this.boardPosition[1][1] + " | " + this.boardPosition[2][1]+ " |\n";
        this.Board+= "+---+---+---+\n";
        this.Board+= "| " + this.boardPosition[0][2] + " | " + this.boardPosition[1][2] + " | " + this.boardPosition[2][2]+ " |\n";
        this.Board+= "+---+---+---+\n";
    }
    
    public boolean getFull(){
        for(int x=0; x<3; x++){
            for(int y=0; y<3; y++){
                if(this.boardPosition[y][x].equals(" "))
                    return false;
            }
        }
        return true;
    }
    public boolean getWin(){
        if(!this.boardPosition[0][0].equals(" ")){
            if(this.boardPosition[0][0].equals(this.boardPosition[0][1]) && this.boardPosition[0][1].equals(this.boardPosition[0][2]))//down the left
                return true;
        }
        else if(!this.boardPosition[1][0].equals(" ")){
            if(this.boardPosition[1][0].equals(this.boardPosition[1][1]) && this.boardPosition[1][1].equals(this.boardPosition[1][2]))//down the middle
                return true;
        }
        else if(!this.boardPosition[2][0].equals(" ")){
            if(this.boardPosition[2][0].equals(this.boardPosition[2][1]) && this.boardPosition[2][1].equals(this.boardPosition[2][2]))//down the right
                return true;
        }
        else if(!this.boardPosition[0][0].equals(" ")){
            if(this.boardPosition[0][0].equals(this.boardPosition[1][0]) && this.boardPosition[1][0].equals(this.boardPosition[2][0]))//across the top
                return true;
        }
        else if(!this.boardPosition[0][1].equals(" ")){
            if(this.boardPosition[0][1].equals(this.boardPosition[1][1]) && this.boardPosition[1][1].equals(this.boardPosition[2][1]))//across the middle
                return true;
        }
        else if(!this.boardPosition[0][2].equals(" ")){
            if(this.boardPosition[0][2].equals(this.boardPosition[1][2]) && this.boardPosition[1][2].equals(this.boardPosition[2][2]))//across the bottom
                return true;
        }
        else if(!this.boardPosition[0][0].equals(" ")){
            if(this.boardPosition[0][0].equals(this.boardPosition[1][1]) && this.boardPosition[1][1].equals(this.boardPosition[2][2]))//diag left to right
                return true;
        }
        else if(!this.boardPosition[2][0].equals(" ")){
            if(this.boardPosition[2][0].equals(this.boardPosition[1][1]) && this.boardPosition[1][1].equals(this.boardPosition[0][2]))//diag right to left
                return true;
        }
            return false;
    }
}
