
import java.util.Scanner;

public class TicTacToeGame implements Game{
    
    public static void makeXmove(TicTacToe TTT){
        boolean moved = false;
        while(!moved){
            int x = ((int)(Math.random() * (3)));
            System.out.println("x="+ x);
            int y = ((int)(Math.random() * (3)));
            System.out.println("x="+ y);
            if(TTT.checkMove(x, y)){
                TTT.addMove(x, y, "X");
                moved = true;
            }
        }
    }

    @Override
    public int playGame() {
            Scanner scan;
            scan = new Scanner(System.in);
            String turn = "";
            TicTacToe TTT = new TicTacToe();
            while (!TTT.getWin()) {
                if(TTT.getFull()){
                    turn = "Nobody";
                    break;
                }
                    
                turn = "O";
                System.out.println(TTT.getBoard());
                boolean Notmoved = true;
                while(Notmoved){
                    System.out.println("Your turn (O) - where (row col)?");
                    int x = scan.nextInt();
                    int y = scan.nextInt();
                    if(x >= 0 && x < 3 && y >= 0 && y < 3) {
                      if (TTT.checkMove(x, y)) {
                          TTT.addMove(x, y, "O");
                          Notmoved = false;
                      }
                      else{
                          System.out.println("Move Invalid");
                          Notmoved = true;
                      }
                    }
                }
                if(TTT.getWin() || TTT.getFull()){
                    if(TTT.getWin())
                        break;
                    turn = "Nobody";
                    break;
                }
                makeXmove(TTT);
                turn = "X";
            }
            String draw = "";
            if(turn.equals("Nobody")){
                draw = " Its a draw!";
            }      
            System.out.println(turn + " Wins!" + draw);
            System.out.println(TTT.getBoard());
        switch (turn) {
            case "O":
                return 100;
            case "X":
                return 0;
            default:
                return 50;
        }
    }
}
