import java.util.Scanner;


public class BaseballGame implements Game{

    @Override
    public int playGame(){
        Scanner scan = new Scanner(System.in);
        Key MyKey = new Key();
        int check;
        String result="";
        int guesses = 0;
        boolean dontStop = true;
        System.out.println("Do you need instructions on how to play?(y/n)");
        if(scan.next().equals("y"))
            System.out.println("Play Ball is a number guessing game where the user \n" +
"guesses 3 non-repeating numbers, each between 0- 9 \n" +
"inclusive. 'Strikes' tells the user how many of the \n" +
"numbers he has chosen are correct and in the right \n" +
"place. 'Balls' tells the user how many numbers are \n" +
"correct but in the wrong place. When the user guesses \n" +
"the correct sequence, they have won!");
        System.out.println("Strike out sequence -- " + MyKey.getKey() + "\n");
        while (dontStop){
            System.out.println("SWING!!!");
            dontStop = false;
            if(scan.hasNextInt(10)){
                check = scan.nextInt(10);
                if(check < 0 || check > 999){
                    System.out.println("Please enter a valid number. \n");
                    dontStop = true;
                }
                else if(check %10 == check /10 %10 || check /10 %10 == check /100 %10 || check %10 == check /100 %10){
                    System.out.println("Pleast enter a valid number. \n");
                    dontStop = true;
                }
                else{
                    guesses++;
                    result = MyKey.CheckKey(check);
                    System.out.println(result);
                    dontStop = true;
                    if(result.equals("Correct!")){
                        System.out.println("You win! You took " + guesses + " guesses to find the right answer.");
                            dontStop = false;
                    }
                }
            }
            else{
                dontStop = true;
                System.out.println("Please enter a valid number. \n");
            }
        } 
        return(100-10*(guesses));
    }
}
