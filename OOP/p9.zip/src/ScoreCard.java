
import java.util.Iterator;
import java.util.Vector;

public class ScoreCard {
    private Vector<Score> ScoreCard;
    
    public ScoreCard(){
        
    }
    
    public void addScore(String gameType, int Score){
        Score score = new Score(gameType, Score);
        this.ScoreCard.add(score);
    }
    
    public String printCard(){
        int cursor = 0;
        String output = "";
        int hmCount = 0;
        int bbCount= 0;
        int tttCount = 0;
        double hmAvg = 0;
        double bbAvg = 0;
        double tttAvg = 0;
        for(Iterator<Score> iterator = this.ScoreCard.iterator() ; iterator.hasNext();cursor ++){
           output += (cursor + ") " + iterator.next().getScore() + "\n");
        }
        //get HM avg
        for(Iterator<Score> iterator = this.ScoreCard.iterator() ; iterator.hasNext();cursor ++){
           if(iterator.next().getType() == 1)
           {
               hmCount++;
               hmAvg += iterator.next().getScoreNum();
           }
        }
        // get BB avg
        for(Iterator<Score> iterator = this.ScoreCard.iterator() ; iterator.hasNext();cursor ++){
           if(iterator.next().getType() == 2)
           {
               bbCount++;
               bbAvg += iterator.next().getScoreNum();
           }
        }
        //get TTT avg
        for(Iterator<Score> iterator = this.ScoreCard.iterator() ; iterator.hasNext();cursor ++){
           if(iterator.next().getType() == 3)
           {
               tttCount++;
               tttAvg += iterator.next().getScoreNum();
           }
        }
        hmAvg = hmAvg / hmCount;
        bbAvg = bbAvg / bbCount;
        tttAvg = tttAvg / tttCount;
        output += "Hangman played: " + hmCount + " times\n";
        output += "Hangman average is: " + hmAvg + " points\n";
        output += "Hangman played: " + bbCount + " times\n";
        output += "Hangman average is: " + bbAvg + " points\n";
        output += "Hangman played: " + tttCount + " times\n";
        output += "Hangman average is: " + tttAvg + " points\n";
        return output;
    }
}
