public interface Game{
     int playGame();
}