/**
 *  Enumeration for the various states of the game
 */
public enum GameState {
   PLAYING, DRAW, CROSS_WON, NOUGHT_WON, QUIT
}