/**
 * Enumeration for the seeds and cell contents
 */
public enum Seed {
   EMPTY, CROSS, NOUGHT
}